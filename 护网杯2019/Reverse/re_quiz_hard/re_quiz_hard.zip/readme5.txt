<----flag input censored---->
9d79fdd15613aa52a17fb2728177e4a5
be31ea3193fd232042cac499a5719e36

note: the result of 
```
from hashlib import md5, sha1
md5(sha1(flag).hexdigest()).hexdigest()
```
 is 'edb31b6cf637e28caaf60fb146fe9ae9'