note: the result of 
```
from hashlib import md5, sha1
md5(sha1(flag).hexdigest()).hexdigest()
```
 is 'ce5d58b6ddd689aa873c29271b1de0c7'